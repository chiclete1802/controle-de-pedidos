﻿namespace Controle_de_Estoque
{
}
namespace Controle_de_Estoque
{


    public partial class Controle_PedidosDataSet
    {
    }
}
namespace Controle_de_Estoque {
    
    
    public partial class Controle_PedidosDataSet {
    }
}
