﻿namespace Controle_de_Estoque.Dados
{


    partial class DataSet_Banco1
    {
    }
}

namespace Controle_de_Estoque.Dados.DataSet_Banco1TableAdapters
{


    public partial class Usuarios1TableAdapter
    {
    }
}
