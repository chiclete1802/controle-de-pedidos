﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Controle_de_Estoque.Classes
{
    class VariáveisGlobais
    {
        public static int Tela = 0;
        public static int ID_Ped = 0;
        public static int ID_Item = 0;
        public static int QuantItem;
        public static bool Ren = false;
    }
}
